const priceContracts: {cakeAddress: string, busdAddress: string, lpAddress:string} = {
  cakeAddress: '0x3Cae530766B29CCCB74e1e7ab24E9828C3EA7bE9',
  busdAddress: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
  lpAddress: '0x53bdaee73d70b2b8490e66bf5b1008b842e20c29'
}

export default priceContracts