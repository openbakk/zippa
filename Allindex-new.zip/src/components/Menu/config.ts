import { MenuEntry } from '@nolievip/allindex-uikit'

const config: MenuEntry[] = [
  {
    label: 'Home',
    icon: 'HomeIcon',
    href: '/home',
  },
  {
    label: 'Trade',
    icon: 'TradeIcon',
    initialOpenState: true,
    items: [
      {
        label: 'Swap',
        href: '/swap',
      },
      {
        label: 'Liquidity',
        href: '/pool',
      },
    ],
  },
  {
    label: 'Farms(Coming Soon)',
    icon: 'FarmIcon',
    href: '',
  },
  {
    label: 'Pools(Coming Soon)',
    icon: 'PoolIcon',
    href: '',
  },
  // {
  //   label: 'Leveraged farming',
  //   icon: 'PoolIcon',
  //   href: 'http://egonswap.io/comingsoon',
  // },
  // {
  //   label: 'LaunchPAD',
  //   icon: 'PoolIcon',
  //   href: 'http://egonswap.io/#/comingsoon',
  // },
  // {
  //   label: 'Lottery',
  //   icon: 'TicketIcon',
  //   href: 'http://egonswap.io/#/comingsoon'
  // },
  // {
  //   label: 'Referral',
  //   icon: 'GroupsIcon',
  //   href: 'http://egonswap.io/#/referral',
  // },
  // {
  //   label: 'Info',
  //   icon: 'InfoIcon',
  //   href: 'https://info.Allindex.co',
  // },
  // {
  //   label: 'GooCoins Pool',
  //   icon: 'PoolIcon',
  //   href: 'https://pool.goocoins.info/',
  // },
  // {
  //   label: 'GooCoins Explorer',
  //   icon: 'InfoIcon',
  //   href: 'https://explorer.goocoins.info/info',
  // },
  // {
  //   label: 'Price Charts',
  //   icon: 'InfoIcon',
  //   items: [
  //     {
  //       label: 'DexGuru',
  //       href: 'https://dex.guru/',
  //     },
  //     {
  //       label: 'PooCoin',
  //       href: 'https://poocoin.app/',
  //     },
  //     {
  //       label: 'BoggedFinance',
  //       href: 'https://charts.bogged.finance/',
  //     },
  //     {
  //       label: 'DexTools',
  //       href: 'https://www.dextools.io/',
  //     },
  //   ],
  // },
  // {
  //   label: 'Audit Report',
  //   icon: 'TicketIcon',
  //   items: [
  //     {
  //       label: 'BscScan',
  //       href: 'https://bscscan.com/',
  //     },
  //     {
  //       label: 'DappRadar',
  //       href: 'https://dappradar.com/',
  //     },
  //     {
  //       label: 'CoinGecko',
  //       href: 'https://www.coingecko.com/en/',
  //     },
  //     {
  //       label: 'LiveCoinWatch',
  //       href: 'https://www.livecoinwatch.com/',
  //     },
  //     {
  //       label: 'Vfat',
  //       href: 'https://vfat.tools/',
  //     },
  //   ],
  // },
  {
    label: 'Info',
    icon: 'NftIcon',
    items: [
      {
        label: 'BscScan',
        href: 'https://bscscan.com/address/0x3Cae530766B29CCCB74e1e7ab24E9828C3EA7bE9',
      },
       {
         label: 'Poocoin',
         href: 'https://poocoin.app/tokens/0x3Cae530766B29CCCB74e1e7ab24E9828C3EA7bE9',
       },
       {
         label: 'Audit',
         href: 'https://github.com/SpyWolfNetwork/Smart_Contract_Audits/blob/main/May/Allindex_Network_0x3Cae530766B29CCCB74e1e7ab24E9828C3EA7bE9.pdf',
       },
      // {
      //   label: 'LiveCoinWatch',
      //   href: 'https://www.livecoinwatch.com/',
      // },
      // {
      //   label: 'Vfat',
      //   href: 'https://vfat.tools/',
      // },
    ],
  },
  {
    label: 'More',
    icon: 'MoreIcon',
    initialOpenState: true,
    items: [
      {
        label: 'AlliNFT - Market NFT',
        href: 'https://nft.allindex.network/',
      },
      {
        label: 'Wallindex - Wallet Crypto',
        href: 'https://wallet.allindex.network/',
      },
      {
        label: 'Telegram EN',
        href: 'https://t.me/allindex_network',
      },
      {
        label: 'Telegram PT',
        href: 'https://t.me/allindex_network_pt',
      },
      {
        label: 'Twitter',
        href: 'https://twitter.com/allindex_web3',
      },
      // {
      //   label: 'Blog',
      //   href: 'https://egonswap.medium.com/',
      // },
      // {
      //   label: 'Voting',
      //   href: 'http://egonswap.io/comingsoon',
      // },
    ],
  },
  // {
  //   label: 'Partnerships/IFO',
  //   icon: 'GooseIcon',
  //   href: 'https://docs.google.com/forms/d/e/1FAIpQLSe7ycrw8Dq4C5Vjc9WNlRtTxEhFDB1Ny6jlAByZ2Y6qBo7SKg/viewform?usp=sf_link',
  // },
  // {
  //   label: 'Audit by Hacken',
  //   icon: 'AuditIcon',
  //   href: 'https://www.egonswap.io/files/hackenAudit.pdf',
  // },
  // {
  //   label: 'Audit by CertiK',
  //   icon: 'AuditIcon',
  //   href: 'https://certik.org/projects/goose-finance',
  // },
]

export default config
